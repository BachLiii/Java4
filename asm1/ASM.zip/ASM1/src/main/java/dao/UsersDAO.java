package dao;

import java.util.ArrayList;
import java.util.List;

import entity.Users;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import utils.XJPA;

public class UsersDAO implements mainDAO<Users, String> {

	@Override
	public List<Users> findAll() {
		EntityManager manager = XJPA.getEntityManager();
		List<Users> list = new ArrayList<>();
		try {
			manager.getTransaction().begin();
			TypedQuery<Users> query = manager.createQuery("from Users", Users.class);
			list = query.getResultList();
			manager.getTransaction().commit();
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
		} finally {
			manager.close();
		}
		return list;
	}

	@Override
	public Users findById(String id) {
		EntityManager manager = XJPA.getEntityManager();
		Users user = null;
		try {
			user = manager.find(Users.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
		}
		return user;
	}

	@Override
	public void create(Users t) {
		EntityManager manager = XJPA.getEntityManager();
		try {
			manager.getTransaction().begin();
			manager.persist(t);
			manager.getTransaction().commit();
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
		} finally {
			manager.close();
		}
	}

	@Override
	public boolean deleteById(String id) {
		EntityManager manager = XJPA.getEntityManager();
		try {
			manager.getTransaction().begin();
			// Tìm entity cần xóa
			Users entity = manager.find(Users.class, id);

			if (entity != null) {
				manager.remove(entity);
				manager.getTransaction().commit();
				return true;
			}
			manager.getTransaction().rollback();
			return false;
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
			return false;
		} finally {
			manager.close();
		}
	}

	@Override
	public void update(Users t) {
		EntityManager manager = XJPA.getEntityManager();
		try {
			manager.getTransaction().begin();
			manager.merge(t);
			manager.getTransaction().commit();
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
		} finally {
			manager.close();
		}
	}

	public Users findByIdOrEmail(String idOrEmail) {
		EntityManager manager = XJPA.getEntityManager();
		Users user = null;

		try {
			String jpql = "SELECT u FROM Users u WHERE u.id = :id OR u.email = :email";
			TypedQuery<Users> query = manager.createQuery(jpql, Users.class);
			query.setParameter("id", idOrEmail);
			query.setParameter("email", idOrEmail);

			user = query.getSingleResult();

		} catch (NoResultException e) {
			user = null;
		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			manager.close();
		}

		return user;
	}
}