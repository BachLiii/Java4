package dao;

import java.util.ArrayList;
import java.util.List;


import report.ReportShareFriend; 
import entity.Share;
import entity.Video;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import utils.XJPA;

public class ShareDAO implements mainDAO<Share, Integer> {

	@Override
	public List<Share> findAll() {
		EntityManager manager = XJPA.getEntityManager();
		List<Share> list = new ArrayList<>();
		try {
			manager.getTransaction().begin();
			TypedQuery<Share> query = manager.createQuery("from Share", Share.class); 
			list = query.getResultList();
			manager.getTransaction().commit();
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
		} finally {
			manager.close();
		}
		return list;
	}

	@Override
	public Share findById(Integer id) {
		EntityManager manager = XJPA.getEntityManager();
		Share share = null;
		try {
			share = manager.find(Share.class, id); 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
		}
		return share;
	}

	@Override
	public void create(Share t) {
		EntityManager manager = XJPA.getEntityManager();
		try {
			manager.getTransaction().begin();
			manager.persist(t);
			manager.getTransaction().commit();
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
		} finally {
			manager.close();
		}
	}

	@Override
	public boolean deleteById(Integer id) {
		EntityManager manager = XJPA.getEntityManager();
		try {
			manager.getTransaction().begin();
			// Tìm entity cần xóa
			Share entity = manager.find(Share.class, id);
			
			if (entity != null) {
			
				manager.remove(entity);
				manager.getTransaction().commit();
				return true;
			}
			manager.getTransaction().rollback();
			return false;
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
			return false;
		} finally {
			manager.close();
		}
	}

	@Override
	public void update(Share t) {
		EntityManager manager = XJPA.getEntityManager();
		try {
			manager.getTransaction().begin();
			manager.merge(t);
			manager.getTransaction().commit();
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
		} finally {
			manager.close();
		}
	}

	public List<Video> findVideosSharedIn2024() {
		EntityManager manager = XJPA.getEntityManager();
		List<Video> videos = new ArrayList<>();

		try {
			String jpql = "SELECT s.video FROM Share s WHERE YEAR(s.shareDate) = 2024 ORDER BY s.shareDate";
			TypedQuery<Video> query = manager.createQuery(jpql, Video.class);
			videos = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
		}

		return videos;
	}

	public List<Object[]> getShareForVideos() {
		EntityManager manager = XJPA.getEntityManager();
		List<Object[]> results = new ArrayList<>();

		try {
			// Không cần transaction
			String jpql = "SELECT v.title, COUNT(s.id) AS share_count, MIN(s.shareDate) AS min_share_date, MAX(s.shareDate) AS max_share_date "
						+ "FROM Share s JOIN s.video v " + "GROUP BY v.title ORDER BY v.title";
			TypedQuery<Object[]> query = manager.createQuery(jpql, Object[].class);
			results = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
		}

		return results;
	}

	public List<ReportShareFriend> findReportShareFriendsByVideoId(String videoId) {
		EntityManager manager = XJPA.getEntityManager();
		List<ReportShareFriend> reports = new ArrayList<>();

		try {
			String jpql = "SELECT new dto.ReportShareFriend(u.fullname, u.email, s.emails, "
						+ "(SELECT MAX(f.shareDate) FROM Favorite f WHERE f.video.id = :videoId AND f.user.id = u.id), "
						+ "s.shareDate) " 
						+ "FROM Share s JOIN s.user u WHERE s.video.id = :videoId";
			
			TypedQuery<ReportShareFriend> query = manager.createQuery(jpql, ReportShareFriend.class);
			query.setParameter("videoId", videoId);

			reports = query.getResultList();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
		}

		return reports;
	}
}