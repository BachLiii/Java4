package dao;

import java.util.ArrayList;
import java.util.List;

import report.ReportFavoriteUser;
import report.ReportFavorites; 
import entity.Favorite;
import entity.Video;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import utils.XJPA;


public class FavoriteDAO implements mainDAO<Favorite, Integer> {

	@Override
	public List<Favorite> findAll() {
		EntityManager manager = XJPA.getEntityManager();
		List<Favorite> list = new ArrayList<>();
		try {
			manager.getTransaction().begin();
			// Sử dụng TypedQuery để tránh warning và tăng tính an toàn
			TypedQuery<Favorite> query = manager.createQuery("from Favorite", Favorite.class);
			list = query.getResultList();
			manager.getTransaction().commit();
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
		} finally {
			manager.close();
		}
		return list;
	}

	@Override
	public Favorite findById(Integer id) {
		EntityManager manager = XJPA.getEntityManager();
		Favorite favorite = null;
		try {
			manager.getTransaction().begin();
			// Dùng find() là cách đơn giản nhất cho PK
			favorite = manager.find(Favorite.class, id); 
			manager.getTransaction().commit();
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
		} finally {
			manager.close();
		}
		return favorite;
	}

	@Override
	public void create(Favorite t) {
		EntityManager manager = XJPA.getEntityManager();
		try {
			manager.getTransaction().begin();
			manager.persist(t);
			manager.getTransaction().commit();
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
		} finally {
			manager.close();
		}
	}

	@Override
	public boolean deleteById(Integer id) {
		EntityManager manager = XJPA.getEntityManager();
		try {
			manager.getTransaction().begin();
			// Tìm entity cần xóa
			Favorite entity = manager.find(Favorite.class, id);
			
			if (entity != null) {
				manager.remove(entity);
				manager.getTransaction().commit();
				return true;
			}
			manager.getTransaction().rollback(); // Rollback nếu không tìm thấy
			return false;
			
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
			return false;
		} finally {
			manager.close();
		}
	}

	@Override
	public void update(Favorite t) {
		EntityManager manager = XJPA.getEntityManager();
		try {
			manager.getTransaction().begin();
			manager.merge(t);
			manager.getTransaction().commit();
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
		} finally {
			manager.close();
		}
	}

	// --- Các phương thức truy vấn tùy chỉnh ---
	
	public List<Video> findTop10MostFavoritedVideos() {
		EntityManager manager = XJPA.getEntityManager();
		List<Video> videos = new ArrayList<>();

		try {
			manager.getTransaction().begin();

			String jpql = "SELECT f.video FROM Favorite f GROUP BY f.video ORDER BY COUNT(f) DESC";
			TypedQuery<Video> query = manager.createQuery(jpql, Video.class);
			query.setMaxResults(10); 

			videos = query.getResultList();

			manager.getTransaction().commit();
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
		} finally {
			manager.close();
		}

		return videos;
	}

	public List<Video> findVideosWithNoFavorites() {
		EntityManager manager = XJPA.getEntityManager();
		List<Video> videos = new ArrayList<>();

		try {
			manager.getTransaction().begin();

			String jpql = "SELECT v FROM Video v LEFT JOIN v.favorites f WHERE f.id IS NULL";
			TypedQuery<Video> query = manager.createQuery(jpql, Video.class);
			videos = query.getResultList();

			manager.getTransaction().commit();
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
		} finally {
			manager.close();
		}

		return videos;
	}

	public Favorite findByUserIdAndVideoId(String userId, String videoId) {
		EntityManager manager = XJPA.getEntityManager();
		Favorite favorite = null;

		try {
			String jpql = "SELECT f FROM Favorite f WHERE f.user.id = :userId AND f.video.id = :videoId";
			TypedQuery<Favorite> query = manager.createQuery(jpql, Favorite.class);
			query.setParameter("userId", userId);
			query.setParameter("videoId", videoId);

			// Không cần transaction cho lệnh SELECT đơn giản, nhưng vẫn nên dùng findOne 
            // hoặc result list và kiểm tra, tránh dùng getSingleResult() nếu có thể rỗng
			List<Favorite> result = query.getResultList();
			favorite = result.isEmpty() ? null : result.get(0);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
		}

		return favorite;
	}

	public List<Favorite> findFavoritesByUserId(String userId) {
		EntityManager manager = XJPA.getEntityManager();
		List<Favorite> favorites = new ArrayList<>();

		try {
			String jpql = "SELECT f FROM Favorite f WHERE f.user.id = :userId";
			TypedQuery<Favorite> query = manager.createQuery(jpql, Favorite.class);
			query.setParameter("userId", userId);

			favorites = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
		}

		return favorites;
	}

	public List<ReportFavorites> generateFavoriteReport() {
		EntityManager manager = XJPA.getEntityManager();
		List<ReportFavorites> report = new ArrayList<>();

		try {
			String jpql = "SELECT new report.ReportFavorites(f.video.title, COUNT(f), MAX(f.shareDate), MIN(f.shareDate)) FROM Favorite f GROUP BY f.video.title";
			TypedQuery<ReportFavorites> query = manager.createQuery(jpql, ReportFavorites.class);

			report = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
		}

		return report;
	}

	public List<ReportFavoriteUser> findUsersByVideoId(String videoId) {
		EntityManager manager = XJPA.getEntityManager();
		List<ReportFavoriteUser> users = new ArrayList<>();

		try {
			String jpql = "SELECT new report.ReportFavoriteUser(u.id, u.email, u.fullname, f.shareDate) FROM Favorite f JOIN f.user u WHERE f.video.id = :videoId ORDER BY f.shareDate DESC";
			// LƯU Ý: Đã sửa lại "dto.ReportFavoriteUser" thành "report.ReportFavoriteUser" 
			TypedQuery<ReportFavoriteUser> query = manager.createQuery(jpql, ReportFavoriteUser.class);
			query.setParameter("videoId", videoId);

			users = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
		}

		return users;
	}

}