package dao;

import java.util.ArrayList;
import java.util.List;


import entity.Video;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import utils.XJPA;

public class VideoDAO implements mainDAO<Video, String> {

	@Override
	public List<Video> findAll() {
		EntityManager manager = XJPA.getEntityManager();
		List<Video> list = new ArrayList<>();
		try {
			TypedQuery<Video> query = manager.createQuery("from Video", Video.class);
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
		}
		return list;
	}

	public List<Video> findAllActive() {
		EntityManager manager = XJPA.getEntityManager();
		List<Video> list = new ArrayList<>();
		try {
			// Không cần transaction cho lệnh SELECT
			TypedQuery<Video> query = manager.createQuery("from Video where active = true", Video.class);
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
		}
		return list;
	}

	public List<Video> random10Video(String excludeId) {
		EntityManager manager = XJPA.getEntityManager();
		List<Video> videos = new ArrayList<>();

		try {
			String jpql = "SELECT v FROM Video v WHERE v.id != :excludeId AND v.active = true ORDER BY FUNCTION('RAND')";
			TypedQuery<Video> query = manager.createQuery(jpql, Video.class);
			query.setParameter("excludeId", excludeId);
			query.setMaxResults(10);

			videos = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
		}

		return videos;
	}

	@Override
	public Video findById(String id) {
		EntityManager manager = XJPA.getEntityManager();
		Video video = null;
		try {
			video = manager.find(Video.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
		}
		return video;
	}

	@Override
	public void create(Video t) {
		EntityManager manager = XJPA.getEntityManager();
		try {
			manager.getTransaction().begin();
			manager.persist(t);
			manager.getTransaction().commit();
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
		} finally {
			manager.close();
		}
	}

	@Override
	public boolean deleteById(String id) {
		EntityManager manager = XJPA.getEntityManager();
		try {
			manager.getTransaction().begin();
			Video entity = manager.find(Video.class, id);
			
			if (entity != null) {
				manager.remove(entity);
				manager.getTransaction().commit();
				return true;
			}
			manager.getTransaction().rollback();
			return false;
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
			return false;
		} finally {
			manager.close();
		}
	}

	@Override
	public void update(Video t) {
		EntityManager manager = XJPA.getEntityManager();
		try {
			manager.getTransaction().begin();
			manager.merge(t);
			manager.getTransaction().commit();
		} catch (Exception e) {
			if (manager.getTransaction().isActive()) {
				manager.getTransaction().rollback();
			}
			e.printStackTrace();
		} finally {
			manager.close();
		}
	}

	public List<Video> findVideosLikedByUser(String userId) {
		EntityManager manager = XJPA.getEntityManager();
		List<Video> videos = new ArrayList<>();

		try {
			String jpql = "SELECT f.video FROM Favorite f WHERE f.user.id = :userId";
			TypedQuery<Video> query = manager.createQuery(jpql, Video.class);
			query.setParameter("userId", userId);

			videos = query.getResultList();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
		}

		return videos;
	}

}